const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Serve static files from the current directory
app.use(express.static(path.join(__dirname)));

// Route to serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'blackjack.html'));
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'Blackjack game server is running' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Blackjack game server is running on port ${PORT}`);
    console.log(`Access the game at: http://localhost:${PORT}`);
});