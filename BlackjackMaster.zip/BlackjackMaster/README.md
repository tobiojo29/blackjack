# Blackjack Betting Game

A classic Blackjack card game with a comprehensive betting system built with pure HTML, CSS, and JavaScript.

## Features

- **Complete Betting System**: Start with $1000 and place bets using $5, $25, and $100 chips
- **Classic Blackjack Rules**: Hit, stand, dealer plays to 17, blackjack pays 3:2
- **Real-time Balance Tracking**: Monitor your balance, current bet, and total winnings
- **Professional UI**: Sleek black and white design with animated cards
- **Win/Loss Dialogs**: Interactive popups for game results
- **Responsive Design**: Works on desktop and mobile devices

## How to Play

1. Click "New Game" to start
2. Place your bet using the colored chip buttons ($5, $25, $100)
3. Click "Deal Cards" to begin the hand
4. Choose "Hit" to take another card or "Stand" to keep your current total
5. Try to get as close to 21 as possible without going over
6. Dealer must hit on 16 and stand on 17
7. Win or lose money based on the outcome!

## Installation

### For CodeSandbox
1. Create a new sandbox
2. Upload all project files
3. Run `npm install` to install dependencies
4. Start the server with `npm run dev`

### Local Development
```bash
npm install
npm run dev
```

The game will be available at `http://localhost:5000`

## Game Rules

- **Blackjack (21 with first 2 cards)**: Pays 3:2 (e.g., $10 bet wins $25)
- **Regular Win**: Pays 1:1 (e.g., $10 bet wins $20 total)
- **Push (Tie)**: Bet is returned
- **Bust (Over 21)**: Lose your bet
- **Aces**: Count as 11 or 1 (automatically adjusted)
- **Face Cards**: Count as 10

## Files Structure

- `blackjack.html` - Main game interface
- `blackjack.css` - Styling and animations
- `blackjack.js` - Game logic and betting system
- `server.js` - Express server for hosting
- `package.json` - Dependencies and scripts

## Technologies Used

- HTML5
- CSS3 (with animations and gradients)
- Vanilla JavaScript
- Node.js + Express (for serving)

## Browser Support

Works in all modern browsers that support ES6+ features.