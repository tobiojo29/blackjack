// Game state
let deck = [];
let playerHand = [];
let dealerHand = [];
let gameState = 'betting'; // 'betting', 'playing', 'dealer', 'finished'
let wins = 0;
let losses = 0;
let showDealerCard = false;

// Betting system
let balance = 1000; // Starting balance
let currentBet = 0;
let totalWinnings = 0;

// Card utilities
const suits = ['♠', '♥', '♦', '♣'];
const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function createDeck() {
    const newDeck = [];
    suits.forEach(suit => {
        values.forEach(value => {
            newDeck.push({ 
                suit, 
                value, 
                color: suit === '♥' || suit === '♦' ? 'red' : 'black' 
            });
        });
    });
    return newDeck;
}

function shuffleDeck(deck) {
    const newDeck = [...deck];
    for (let i = newDeck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
    }
    return newDeck;
}

function getCardValue(card) {
    if (card.value === 'A') return 11;
    if (['J', 'Q', 'K'].includes(card.value)) return 10;
    return parseInt(card.value);
}

function calculateScore(hand) {
    let score = 0;
    let aces = 0;
    
    hand.forEach(card => {
        if (card.value === 'A') {
            aces++;
            score += 11;
        } else if (['J', 'Q', 'K'].includes(card.value)) {
            score += 10;
        } else {
            score += parseInt(card.value);
        }
    });
    
    while (score > 21 && aces > 0) {
        score -= 10;
        aces--;
    }
    
    return score;
}

// DOM manipulation
function updateGameMessage(message) {
    document.getElementById('gameMessage').textContent = message;
}

function updateScore(elementId, score) {
    document.getElementById(elementId).textContent = score;
}

function updateStats() {
    document.getElementById('wins').textContent = wins;
    document.getElementById('losses').textContent = losses;
    document.getElementById('balance').textContent = balance;
    document.getElementById('currentBet').textContent = currentBet;
    document.getElementById('totalWinnings').textContent = totalWinnings;
}

// Betting functions
function placeBet(amount) {
    if (gameState !== 'betting') return;
    if (balance >= amount) {
        currentBet += amount;
        balance -= amount;
        updateStats();
        updateGameMessage(`Current bet: $${currentBet}. Click "Deal Cards" when ready!`);
        
        // Show deal button when bet is placed
        if (currentBet > 0) {
            showControls(['dealBtn', 'clearBetBtn']);
        }
    } else {
        updateGameMessage('Insufficient balance for this bet!');
    }
}

function clearBet() {
    if (gameState !== 'betting') return;
    balance += currentBet;
    currentBet = 0;
    updateStats();
    updateGameMessage('Place your bet to start the game!');
    showControls(['chip5', 'chip25', 'chip100']);
}

function dealCards() {
    if (currentBet === 0) {
        updateGameMessage('Please place a bet first!');
        return;
    }
    
    gameState = 'playing';
    deck = shuffleDeck(createDeck());
    playerHand = [deck.pop(), deck.pop()];
    dealerHand = [deck.pop(), deck.pop()];
    showDealerCard = false;
    
    renderCards('playerCards', playerHand);
    renderCards('dealerCards', dealerHand, true);
    
    updateScore('playerScore', calculateScore(playerHand));
    updateScore('dealerScore', '?');
    
    const playerScore = calculateScore(playerHand);
    if (playerScore === 21) {
        // Blackjack!
        handleBlackjack();
    } else {
        updateGameMessage(`Your turn! Current bet: $${currentBet}`);
        showControls(['hitBtn', 'standBtn']);
    }
}

function handleBlackjack() {
    showDealerCard = true;
    renderCards('dealerCards', dealerHand);
    updateScore('dealerScore', calculateScore(dealerHand));
    
    const dealerScore = calculateScore(dealerHand);
    gameState = 'finished';
    
    if (dealerScore === 21) {
        // Push
        balance += currentBet;
        updateGameMessage('Push! Both have blackjack - bet returned.');
        showDialog('winDialog', 'Push! Both have blackjack. Your bet has been returned.');
    } else {
        // Player blackjack wins 3:2
        const winnings = Math.floor(currentBet * 2.5);
        balance += winnings;
        totalWinnings += winnings - currentBet;
        wins++;
        updateGameMessage(`Blackjack! You win $${winnings}!`);
        showDialog('winDialog', `Blackjack! You won $${winnings}!`);
    }
    
    currentBet = 0;
    updateStats();
    showControls(['newGameBtn']);
}

function createCardElement(card, hidden = false) {
    const cardDiv = document.createElement('div');
    cardDiv.className = `playing-card ${card.color}`;
    
    if (hidden) {
        cardDiv.classList.add('hidden');
        cardDiv.innerHTML = `
            <div class="card-value">?</div>
            <div class="card-suit">?</div>
        `;
    } else {
        cardDiv.innerHTML = `
            <div class="card-value">${card.value}</div>
            <div class="card-suit">${card.suit}</div>
        `;
    }
    
    return cardDiv;
}

function renderCards(containerId, hand, hideSecond = false) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    
    hand.forEach((card, index) => {
        const hidden = hideSecond && index === 1;
        const cardElement = createCardElement(card, hidden);
        container.appendChild(cardElement);
    });
}

function showControls(controlIds) {
    // Hide all controls first
    ['newGameBtn', 'hitBtn', 'standBtn', 'dealBtn', 'clearBetBtn', 'chip5', 'chip25', 'chip100'].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'none';
    });
    
    // Show specified controls
    controlIds.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'inline-block';
    });
}

function showDialog(dialogId, message) {
    document.getElementById(dialogId).style.display = 'flex';
    const messageElement = dialogId === 'winDialog' ? 'winMessage' : 'loseMessage';
    document.getElementById(messageElement).textContent = message;
}

function closeDialog(dialogId) {
    document.getElementById(dialogId).style.display = 'none';
}

// Game logic
function startNewGame() {
    gameState = 'betting';
    currentBet = 0;
    playerHand = [];
    dealerHand = [];
    showDealerCard = false;
    
    // Clear cards display
    document.getElementById('playerCards').innerHTML = '';
    document.getElementById('dealerCards').innerHTML = '';
    updateScore('playerScore', '0');
    updateScore('dealerScore', '0');
    
    updateGameMessage('Place your bet to start the game!');
    updateStats();
    showControls(['chip5', 'chip25', 'chip100']);
}

function hit() {
    if (gameState !== 'playing' || deck.length === 0) return;

    const newCard = deck[0];
    playerHand.push(newCard);
    deck = deck.slice(1);

    renderCards('playerCards', playerHand);
    
    const playerScore = calculateScore(playerHand);
    updateScore('playerScore', playerScore);
    
    if (playerScore > 21) {
        gameState = 'finished';
        losses++;
        const lostAmount = currentBet;
        totalWinnings -= currentBet;
        currentBet = 0;
        updateGameMessage(`Bust! You lose $${lostAmount}!`);
        showDealerCard = true;
        renderCards('dealerCards', dealerHand);
        updateScore('dealerScore', calculateScore(dealerHand));
        updateStats();
        showControls(['newGameBtn']);
        showDialog('loseDialog', `Bust! You went over 21 and lost $${lostAmount}!`);
    } else if (playerScore === 21) {
        stand();
    }
}

function stand() {
    if (gameState !== 'playing') return;

    gameState = 'dealer';
    showDealerCard = true;
    renderCards('dealerCards', dealerHand);
    updateScore('dealerScore', calculateScore(dealerHand));
    updateGameMessage('Dealer is playing...');
    showControls([]);

    // Dealer plays after delay
    setTimeout(() => {
        playDealerHand();
    }, 1000);
}

function playDealerHand() {
    let dealerScore = calculateScore(dealerHand);

    const dealNextCard = () => {
        if (dealerScore < 17 && deck.length > 0) {
            const newCard = deck[0];
            dealerHand.push(newCard);
            deck = deck.slice(1);
            dealerScore = calculateScore(dealerHand);
            
            renderCards('dealerCards', dealerHand);
            updateScore('dealerScore', dealerScore);

            setTimeout(dealNextCard, 1000);
        } else {
            // Determine winner
            determineWinner();
        }
    };

    dealNextCard();
}

function determineWinner() {
    const playerScore = calculateScore(playerHand);
    const dealerScore = calculateScore(dealerHand);
    const betAmount = currentBet;

    gameState = 'finished';
    showControls(['newGameBtn']);

    if (dealerScore > 21) {
        // Dealer busts, player wins
        const winnings = betAmount * 2;
        balance += winnings;
        totalWinnings += betAmount;
        wins++;
        updateGameMessage(`Dealer busts! You win $${winnings}!`);
        showDialog('winDialog', `Dealer busts! You won $${winnings}!`);
    } else if (playerScore > dealerScore) {
        // Player wins
        const winnings = betAmount * 2;
        balance += winnings;
        totalWinnings += betAmount;
        wins++;
        updateGameMessage(`You win $${winnings}! ${playerScore} beats ${dealerScore}!`);
        showDialog('winDialog', `You won $${winnings}! ${playerScore} beats ${dealerScore}!`);
    } else if (dealerScore > playerScore) {
        // Dealer wins
        losses++;
        totalWinnings -= betAmount;
        updateGameMessage(`You lose $${betAmount}! Dealer has ${dealerScore}, you have ${playerScore}.`);
        showDialog('loseDialog', `You lost $${betAmount}! Dealer has ${dealerScore}, you have ${playerScore}.`);
    } else {
        // Push - tie
        balance += betAmount;
        updateGameMessage('Push! Same score - bet returned.');
        showDialog('winDialog', `Push! Both have ${playerScore}. Your bet of $${betAmount} has been returned.`);
    }
    
    currentBet = 0;
    updateStats();
}

// Initialize game
document.addEventListener('DOMContentLoaded', function() {
    updateStats();
    updateGameMessage('Click "New Game" to start!');
    showControls(['newGameBtn']);
});