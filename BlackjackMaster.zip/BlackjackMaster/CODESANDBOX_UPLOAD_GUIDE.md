# How to Upload Blackjack Game to CodeSandbox

## Method 1: Direct File Upload

1. Go to [codesandbox.io](https://codesandbox.io)
2. Click "Create Sandbox"
3. Choose "Import from GitHub" or "Upload Files"
4. Upload these files from your project:
   - `blackjack.html`
   - `blackjack.css` 
   - `blackjack.js`
   - `server.js`
   - `package.json`
   - `README.md`
   - `sandbox.config.json`

## Method 2: GitHub Import (Recommended)

1. First, create a GitHub repository with these files
2. Go to CodeSandbox
3. Click "Import from GitHub"
4. Enter your repository URL
5. CodeSandbox will automatically set up the project

## Files to Include

Your project contains these essential files:

### Core Game Files
- **blackjack.html** - Main game interface
- **blackjack.css** - Styling and chip button designs
- **blackjack.js** - Complete betting system and game logic
- **server.js** - Express server to run the game

### Configuration Files
- **package.json** - Updated with proper project details
- **sandbox.config.json** - CodeSandbox configuration
- **README.md** - Complete project documentation

## After Upload

1. CodeSandbox will automatically run `npm install`
2. The server will start on port 5000
3. Your game will be accessible via the preview window
4. Share the sandbox URL with others to play your game

## Features Included

- Complete betting system with $5, $25, $100 chips
- Balance tracking starting at $1000
- Win/loss money calculations
- Professional casino-style interface
- Responsive design for all devices

Your blackjack game is now ready for CodeSandbox!